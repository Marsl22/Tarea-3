# Tarea 3 — Correcciones aplicadas

## 1. WebGPU + WGSL — Brazo Robótico (`parte-b-webgpu-wgsl/brazo-robotico/index.html`)

**Error original:**
```
[Buffer] bound with size 296 at group 0, binding 0 is too small.
The pipeline requires a buffer binding which is at least 304 bytes.
```

**Causa:** WGSL alinea los structs de un `uniform buffer` como std140: cada campo se
alinea a un múltiplo de su tamaño de alineación (`vec3`/`mat3x3` → 16 bytes), y el
**tamaño total del struct se redondea hacia arriba al mayor alineamiento usado (16 bytes)**.
Con `model+view+proj+normalMat+lightPos+viewPos+color+amb+dif+spec+shininess`
el contenido real ocupa 300 bytes, que deben redondearse a **304**. El buffer se
estaba creando con 296 bytes (8 bytes menos de lo requerido), por eso el pipeline
rechazaba el binding en cada `DrawIndexed`.

**Fix:** se cambió `UB_SIZE` de `296` a `304`. El `Float32Array` de escritura
(`ubData`) ya se dimensiona a partir de `UB_SIZE/4`, así que crece automáticamente
a 76 floats; los 2 floats finales quedan en 0 como relleno (padding), tal como
exige el layout del struct.

## 2. WebGPU + TSL — Brazo Robótico y Sistema Solar (`parte-c-webgpu-tsl/*`)

**Error original:**
```
Access to script at 'https://unpkg.com/three@0.168.0/examples/jsm/renderers/webgpu/WebGPURenderer.js'
from origin 'http://localhost:8000' has been blocked by CORS policy...
```

**Causa:** el import map apuntaba a:
- `three` → el build **clásico** (`three.module.js`), que **no incluye** `WebGPURenderer` ni TSL.
- `WebGPURenderer.js` se importaba aparte desde `examples/jsm/...` en unpkg, una ruta
  que dispara redirecciones internas que unpkg no siempre sirve con cabeceras CORS completas.
- `three/tsl` apuntaba a un archivo fuente interno (`src/nodes/tsl/TSLCore.js`) que no es
  un build empaquetado y no es la forma soportada de importar TSL.

**Fix:** se reemplazó el import map por el patrón oficial de Three.js para WebGPU + TSL,
usando jsDelivr (CDN con CORS estable) y los builds correctos:

```html
<script type="importmap">
{
  "imports": {
    "three": "https://cdn.jsdelivr.net/npm/three@0.168.0/build/three.webgpu.js",
    "three/webgpu": "https://cdn.jsdelivr.net/npm/three@0.168.0/build/three.webgpu.js",
    "three/tsl": "https://cdn.jsdelivr.net/npm/three@0.168.0/build/three.tsl.js",
    "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.168.0/examples/jsm/"
  }
}
</script>
```

Como `three.webgpu.js` ya incluye `THREE.WebGPURenderer`, se eliminó el import
separado (`import WebGPURenderer from 'three/addons/renderers/webgpu/WebGPURenderer.js'`)
y ahora se usa `new THREE.WebGPURenderer(...)` directamente. También se agregó
`await renderer.init();` antes del primer render, requerido en builds recientes
de Three.js antes de dibujar con WebGPU.

## Cómo ejecutar

Cualquier servidor estático local funciona (los módulos ES requieren `http://`, no `file://`):

```bash
cd tarea3_corregida
python3 -m http.server 8000
```

Luego abre en Chrome/Edge 113+ (para las partes WebGPU necesitas un navegador con
soporte WebGPU habilitado):

- `http://localhost:8000/parte-a-webgl2/brazo-robotico/`
- `http://localhost:8000/parte-a-webgl2/sistema-solar/`
- `http://localhost:8000/parte-b-webgpu-wgsl/brazo-robotico/`
- `http://localhost:8000/parte-b-webgpu-wgsl/sistema-solar/`
- `http://localhost:8000/parte-c-webgpu-tsl/brazo-robotico/`
- `http://localhost:8000/parte-c-webgpu-tsl/sistema-solar/`

Necesitas conexión a internet la primera vez que abras las partes B y C, ya que
cargan Three.js desde jsDelivr vía import map.
